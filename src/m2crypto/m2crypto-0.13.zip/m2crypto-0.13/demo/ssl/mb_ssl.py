HOST = 'www.networkcar.com'
URL = '/networkcar/pub/webservices/'
URL = URL + 'Vehicle.VehicleInfoHome/Vehicle.VehicleInfoHome.wsdl'

def soapy():
    import soap
    # url = http://tedweb.networkcar.com/networkcar/pub/webservices 
    #url = "https://%s/networkcar/pub/webservices" % HOST
    #url = url + "/Customer.CustomerInfoHome/Customer.CustomerInfoHome.wsdl"
    url = HOST
    proxy = SOAPpy.WSDL.Proxy(url)
    cars = getCars(proxy, "scedison", "edison")
    print cars

def native():
    import httplib
    conn = httplib.HTTPSConnection(HOST)
    conn.putrequest('GET', URL)
    conn.endheaders()
    response = conn.getresponse()
    print response.read()

def m2():
    import M2Crypto
    import sys

    ctx = M2Crypto.SSL.Context()
    ctx.set_info_callback()
    print "Host ", HOST
    h = M2Crypto.httpslib.HTTPSConnection(HOST, 443, ssl_context = ctx)
    h.set_debuglevel(1)
    print "Getting ", URL
    h.putrequest('GET', URL)
    h.putheader('Accept', 'text/html')
    h.putheader('Accept', 'text/plain')
    h.putheader('Connection', 'close')
    h.endheaders()
    resp = h.getresponse()
    f = resp.fp
    c = 0
    while 1:
        # Either of following two works.
        #data = f.readline()   
        data = resp.read()
        if not data: break
        c = c + len(data)
        #print data
        sys.stdout.write(data)
        sys.stdout.flush()
    print c, 'bytes read'
    f.close()
    h.close()

if __name__ == "__main__": 
    m2()
