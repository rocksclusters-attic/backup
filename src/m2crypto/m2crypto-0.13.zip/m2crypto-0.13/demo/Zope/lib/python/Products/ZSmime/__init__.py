"""ZSmime.__init__

Copyright (c) 2000 Ng Pheng Siong. All rights reserved.
This software is released under the ZPL. Usual disclaimers apply."""

RCS_id = '$Id: __init__.py,v 1.1 2000/05/07 15:59:27 ngps Exp $'
__version__='$Revision: 1.1 $'[11:-2]

import SmimeTag

