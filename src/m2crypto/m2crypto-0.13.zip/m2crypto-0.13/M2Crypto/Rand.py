"""M2Crypto wrapper for OpenSSL PRNG. Requires OpenSSL 0.9.5 and above.

Copyright (c) 1999-2003 Ng Pheng Siong. All rights reserved."""

RCS_id='$Id: Rand.py,v 1.3 2002/12/23 03:49:43 ngps Exp $'

import m2

rand_seed           = m2.rand_seed
rand_add            = m2.rand_add
load_file           = m2.rand_load_file
save_file           = m2.rand_save_file
rand_bytes          = m2.rand_bytes
rand_pseudo_bytes   = m2.rand_pseudo_bytes

def estimate_entropy(buf):
    raise NotImplementedError


