"""M2Crypto.SSL.Error

Copyright (c) 1999-2003 Ng Pheng Siong. All rights reserved."""

RCS_id='$Id: Error.py,v 1.1 2002/12/23 03:58:41 ngps Exp $'

class SSLError(Exception): pass

