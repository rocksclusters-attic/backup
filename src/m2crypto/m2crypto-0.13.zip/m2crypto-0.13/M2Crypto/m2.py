"""M2Crypto

Copyright (c) 1999-2003 Ng Pheng Siong. All rights reserved."""

RCS_id='$Id: m2.py,v 1.3 2002/12/29 12:44:33 ngps Exp $'

from __m2crypto import *
lib_init()


